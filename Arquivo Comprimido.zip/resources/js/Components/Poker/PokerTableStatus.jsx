import React from 'react';

function seatRoleLabel(seat) {
    const roles = [];

    if (seat.isDealer) {
        roles.push('Dealer');
    }

    if (seat.isSmallBlind) {
        roles.push('Small blind');
    }

    if (seat.isBigBlind) {
        roles.push('Big blind');
    }

    return roles.length > 0 ? roles.join(' • ') : 'Assento';
}

function metric(label, value, highlight = false) {
    return (
        <div className={`rounded-xl border px-2.5 py-2 shadow-lg sm:rounded-2xl sm:p-4 ${highlight ? 'border-amber-200/40 bg-amber-300/15' : 'border-white/10 bg-white/[0.06]'}`}>
            <span className="text-[0.55rem] font-bold uppercase tracking-[0.14em] text-emerald-100/70 sm:text-xs sm:tracking-[0.2em]">{label}</span>
            <strong className="mt-0.5 block truncate text-sm font-black text-white sm:mt-1 sm:text-2xl">{value}</strong>
        </div>
    );
}

export default function PokerTableStatus({ state }) {
    const seats = Array.isArray(state.tableSeats) ? state.tableSeats : [];

    return (
        <section className="rounded-2xl border border-emerald-200/20 bg-slate-950/65 p-2.5 shadow-2xl shadow-black/40 backdrop-blur sm:rounded-[2rem] sm:p-5">
            <div className="grid grid-cols-3 gap-1.5 sm:gap-3 lg:grid-cols-7">
                {metric('Street', state.streetLabel)}
                {metric('Pote', state.pot, true)}
                {metric('Stack', state.playerStack)}
                {metric('Oponente', state.opponentStack)}
                {metric('Pagar', state.amountToCall ?? state.currentBet)}
                {metric('Mão', state.bestHand?.name ?? 'Aguardando')}

                <div className="col-span-3 rounded-xl border border-amber-200/35 bg-black/25 px-2.5 py-2 shadow-lg sm:rounded-2xl sm:p-4 lg:col-span-1">
                    <span className="text-[0.55rem] font-bold uppercase tracking-[0.14em] text-amber-100/80 sm:text-xs sm:tracking-[0.2em]">Vez atual</span>
                    <strong className="mt-0.5 block text-sm font-black text-white sm:mt-1 sm:text-xl">{state.currentTurn?.actorLabel ?? 'Jogador'}</strong>
                    <span className="mt-0.5 block truncate text-[0.62rem] font-semibold text-emerald-100/80 sm:mt-1 sm:text-xs">{state.currentTurn?.message ?? 'Aguardando ação.'}</span>
                </div>
            </div>

            {seats.length > 0 && (
                <div className="mt-3 hidden sm:block sm:mt-5">
                    <span className="text-xs font-black uppercase tracking-[0.25em] text-emerald-200/80">Estrutura da mesa</span>
                    <div className="mt-3 grid gap-3 md:grid-cols-2">
                        {seats.map((seat) => (
                            <div
                                key={seat.id ?? seat.seatNumber}
                                className="rounded-2xl border border-white/10 bg-white/[0.05] px-4 py-3 shadow-inner shadow-black/30"
                            >
                                <strong className="block text-sm text-white">
                                    Assento {seat.seatNumber} — {seat.status === 'occupied' ? 'Ocupado' : 'Livre'}
                                </strong>
                                <span className="text-xs text-emerald-100/80">
                                    {seatRoleLabel(seat)} • Stack {seat.stack}
                                </span>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </section>
    );
}
