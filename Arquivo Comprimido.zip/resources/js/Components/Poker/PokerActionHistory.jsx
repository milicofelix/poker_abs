import React from 'react';

function actorLabel(item) {
    if (item?.actorLabel) {
        return item.actorLabel;
    }

    return item?.actor === 'opponent' ? 'Oponente' : 'Você';
}

export default function PokerActionHistory({ history }) {
    if (!history || history.length === 0) {
        return (
            <section className="rounded-xl border border-white/10 bg-slate-950/70 p-2 text-xs text-slate-300 shadow-xl sm:rounded-2xl sm:p-3 sm:text-sm">
                <h2 className="mb-1 text-xs font-black uppercase tracking-[0.14em] text-white sm:mb-1.5 sm:text-sm sm:tracking-[0.18em]">Histórico da mão</h2>
                <p>Nenhuma ação realizada ainda.</p>
            </section>
        );
    }

    return (
        <section className="poker-compact-scroll rounded-xl border border-white/10 bg-slate-950/80 p-1.5 shadow-xl sm:rounded-2xl sm:p-3 max-h-28 overflow-y-auto sm:max-h-44 lg:max-h-[360px]">
            <h2 className="sticky -top-1.5 z-10 mb-1 rounded-t-lg bg-slate-950/95 py-1 text-[0.65rem] font-black uppercase tracking-[0.12em] text-white sm:-top-3 sm:mb-2 sm:text-sm sm:tracking-[0.18em]">Histórico da mão</h2>

            <ol className="space-y-0.5 sm:space-y-1.5">
                {history.map((item, index) => (
                    <li
                        key={`${item.actor}-${item.action}-${index}`}
                        className="rounded-md border border-white/10 bg-white/5 px-1.5 py-1 text-[0.6rem] leading-tight text-slate-200 sm:rounded-xl sm:px-2.5 sm:py-2 sm:text-xs sm:leading-snug"
                    >
                        <div className="flex items-center justify-between gap-1">
                            <strong className={item.actor === 'opponent' ? 'text-amber-200' : 'text-emerald-200'}>
                                {index + 1}. {actorLabel(item)} — {item.street} — {item.action}
                            </strong>

                            <span className="shrink-0 text-slate-400">
                                Pote: {item.pot}
                            </span>
                        </div>

                        <p className="mt-0.5 truncate text-slate-300 sm:line-clamp-2 sm:whitespace-normal">{item.message}</p>
                    </li>
                ))}
            </ol>
        </section>
    );
}
