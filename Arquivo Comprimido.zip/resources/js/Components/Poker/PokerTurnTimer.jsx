import React from 'react';

export default function PokerTurnTimer({ timer }) {
    if (!timer) {
        return null;
    }

    const barClass = timer.isExpired
        ? 'bg-rose-400'
        : timer.secondsRemaining <= 10
            ? 'bg-amber-300'
            : 'bg-emerald-300';

    return (
        <section className="rounded-2xl border border-white/10 bg-slate-950/75 p-2.5 shadow-2xl shadow-black/40 backdrop-blur sm:rounded-[2rem] sm:p-4">
            <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                    <p className="text-[0.58rem] font-black uppercase tracking-[0.2em] text-emerald-200/80 sm:text-xs sm:tracking-[0.28em]">Turn timer</p>
                    <h2 className="mt-0.5 truncate text-sm font-black text-white sm:mt-1 sm:text-xl">{timer.label}</h2>
                    <p className="hidden text-sm text-slate-300 sm:mt-2 sm:block">
                        {timer.isExpired
                            ? 'Tempo esgotado. A mesa pode aplicar ação automática.'
                            : 'Contador sincronizado pela mesa e reiniciado após cada ação.'}
                    </p>
                </div>

                <div className={`shrink-0 rounded-xl border px-3 py-1.5 text-2xl font-black shadow-xl sm:rounded-[1.5rem] sm:px-5 sm:py-3 sm:text-4xl ${timer.secondsRemaining <= 10 ? 'border-amber-200/50 bg-amber-300/15 text-amber-100' : 'border-emerald-200/30 bg-emerald-300/10 text-emerald-100'}`}>
                    {timer.secondsRemaining}s
                </div>
            </div>

            <div className="mt-2 h-2.5 overflow-hidden rounded-full border border-white/10 bg-black/35 p-0.5 sm:mt-4 sm:h-4 sm:p-1">
                <div
                    className={`h-full rounded-full transition-all duration-500 ${barClass}`}
                    style={{ width: `${timer.percentage}%` }}
                />
            </div>
        </section>
    );
}
