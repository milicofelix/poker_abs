<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Poker\PokerPlayController;
use App\Http\Controllers\Poker\PokerRoundActionController;
use App\Http\Controllers\Poker\PokerHandHistoryController;
use App\Http\Controllers\Poker\PokerRankingController;
use App\Http\Controllers\Poker\PokerHandShowController;
use App\Http\Controllers\Poker\PokerHandReplayController;
use App\Http\Controllers\Poker\PokerStatisticsController;
use App\Http\Controllers\Poker\PokerTablePlayController;
use App\Http\Controllers\Poker\PokerTableCreateController;
use App\Http\Controllers\Poker\PokerLobbyController;
use App\Http\Controllers\Poker\PokerTableRoundActionController;
use App\Http\Controllers\Poker\PokerTableStateController;
use App\Http\Controllers\Poker\PokerTableTurnTimeoutController;
use App\Http\Controllers\Poker\PokerTableJoinController;
use App\Http\Controllers\Poker\PokerTableSeatController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Poker\PokerTableLeaveController;
use App\Http\Controllers\Poker\PokerTableNewHandController;
use App\Http\Controllers\Poker\PokerTableBotController;
use App\Http\Controllers\Poker\PokerPrivateTableJoinController;
use App\Http\Controllers\Poker\PokerPrivateTableInviteController;
use App\Http\Controllers\Poker\PokerBankrollHistoryController;
use App\Http\Controllers\Poker\PokerTableRebuyController;
use App\Http\Controllers\Poker\PokerPlayerProfileController;
use App\Http\Controllers\Poker\PokerTournamentController;
use App\Http\Controllers\Poker\PokerTournamentRegistrationController;
use App\Http\Controllers\Poker\PokerTournamentStartController;
use App\Http\Controllers\Poker\PokerTournamentEliminationController;
use App\Http\Controllers\Poker\PokerTournamentBotRegistrationController;
use App\Http\Controllers\Poker\PokerTournamentBlindLevelController;
use App\Http\Controllers\Poker\PokerTournamentFinalTableController;
use App\Http\Controllers\Poker\PokerTournamentReentryController;
use App\Http\Controllers\Poker\PokerTournamentAddonController;
use App\Http\Controllers\Poker\PokerTournamentOfficialClosureController;

Route::get('/', fn () => redirect()->route('poker.play'));

Route::middleware('guest')->group(function (): void {
    Route::get('/login', [LoginController::class, 'create'])->name('login');
    Route::post('/login', [LoginController::class, 'store'])->name('login.store');

    Route::get('/register', [RegisterController::class, 'create'])->name('register');
    Route::post('/register', [RegisterController::class, 'store'])->name('register.store');
});

Route::post('/logout', [LoginController::class, 'destroy'])
    ->middleware('auth')
    ->name('logout');

Route::get('/poker', PokerPlayController::class)->name('poker.play');
Route::post('/poker/actions', PokerRoundActionController::class)->name('poker.actions');
Route::get('/poker/hands', [PokerHandHistoryController::class, 'index'])->name('poker.hands.index');
Route::get('/poker/ranking', PokerRankingController::class)->name('poker.ranking.index');
Route::get('/poker/players/{user}', [PokerPlayerProfileController::class, 'show'])->name('poker.players.show');
Route::get('/poker/hands/{hand}', PokerHandShowController::class)->name('poker.hands.show');
Route::get('/poker/hands/{hand}/replay', PokerHandReplayController::class)->name('poker.hands.replay');
Route::get('/poker/statistics', PokerStatisticsController::class)->name('poker.statistics.index');
Route::get('/poker/tournaments', [PokerTournamentController::class, 'index'])->name('poker.tournaments.index');
Route::get('/poker/tables', fn () => redirect()->route('poker.lobby'))->name('poker.tables.index');
Route::get('/poker/lobby', PokerLobbyController::class)->name('poker.lobby');

Route::middleware('auth')->group(function (): void {
    Route::get('/poker/tables/{table}', PokerTablePlayController::class)->name('poker.tables.show');
    Route::post('/poker/tables', PokerTableCreateController::class)->name('poker.tables.store');
    Route::post('/poker/tables/{table}/actions', PokerTableRoundActionController::class)->name('poker.tables.actions');
    Route::get('/poker/tables/{table}/state', PokerTableStateController::class)->name('poker.tables.state');
    Route::post('/poker/tables/{table}/timeout', PokerTableTurnTimeoutController::class)->name('poker.tables.timeout');
    Route::post('/poker/tables/{table}/join', PokerTableJoinController::class)->name('poker.tables.join');
    Route::post('/poker/tables/{table}/seat', PokerTableSeatController::class)->name('poker.tables.seat');
    Route::post('/poker/tables/{table}/leave', PokerTableLeaveController::class)->name('poker.tables.leave');
    Route::post('/poker/tables/{table}/rebuy', PokerTableRebuyController::class)->name('poker.tables.rebuy');
    Route::post('/poker/tables/{table}/new-hand', PokerTableNewHandController::class)->name('poker.tables.new-hand');
    Route::post('/poker/tables/{table}/bots', PokerTableBotController::class)->name('poker.tables.bots');
    Route::post('/poker/private-tables/join', PokerPrivateTableJoinController::class)->name('poker.private-tables.join');
    Route::get('/poker/invite/{inviteCode}', PokerPrivateTableInviteController::class)->name('poker.private-tables.invite');
    Route::get('/poker/profile', [PokerPlayerProfileController::class, 'current'])->name('poker.profile.show');
    Route::get('/poker/bankroll', PokerBankrollHistoryController::class)->name('poker.bankroll.index');
    Route::post('/poker/tournaments', [PokerTournamentController::class, 'store'])->name('poker.tournaments.store');
    Route::post('/poker/tournaments/{tournament}/register', PokerTournamentRegistrationController::class)->name('poker.tournaments.register');
    Route::post('/poker/tournaments/{tournament}/start', PokerTournamentStartController::class)->name('poker.tournaments.start');
    Route::post('/poker/tournaments/{tournament}/bots', PokerTournamentBotRegistrationController::class)->name('poker.tournaments.bots');
    Route::post('/poker/tournaments/{tournament}/blind-level', PokerTournamentBlindLevelController::class)->name('poker.tournaments.blind-level');
    Route::post('/poker/tournaments/{tournament}/final-table', PokerTournamentFinalTableController::class)->name('poker.tournaments.final-table');
    Route::post('/poker/tournaments/{tournament}/participants/{participant}/reentry', PokerTournamentReentryController::class)->name('poker.tournaments.participants.reentry');
    Route::post('/poker/tournaments/{tournament}/participants/{participant}/addon', PokerTournamentAddonController::class)->name('poker.tournaments.participants.addon');
    Route::post('/poker/tournaments/{tournament}/participants/{participant}/eliminate', PokerTournamentEliminationController::class)->name('poker.tournaments.participants.eliminate');
    Route::post('/poker/tournaments/{tournament}/official-close', PokerTournamentOfficialClosureController::class)->name('poker.tournaments.official-close');
});
