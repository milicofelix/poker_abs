<?php

namespace App\Services\Poker;

use App\Models\Poker\PokerTable;
use App\Models\Poker\PokerTablePlayer;
use App\Models\User;
use Illuminate\Support\Collection;

final class MultiplayerPokerPrivateStateService
{
    /**
     * @param array<string, mixed> $state
     * @return array<string, mixed>
     */
    public function forUser(PokerTable $table, array $state, ?User $user): array
    {
        $state = $this->normalizeInterfaceFlags($state);
        $realPlayers = $this->realPlayers($table);

        if ((bool) data_get($state, 'multiSeat.enabled', false)) {
            return $this->multiSeatPerspective($state, $realPlayers, $user);
        }

        if (! $user) {
            return $this->withPlayersContext(
                $this->withoutPrivateOpponentData($state, 'spectator'),
                $realPlayers,
                null,
                'spectator',
            );
        }

        $currentPlayer = $realPlayers->first(
            static fn (PokerTablePlayer $player): bool => (int) $player->user_id === (int) $user->id,
        );

        if (! $currentPlayer) {
            return $this->withPlayersContext(
                $this->withoutPrivateOpponentData($state, 'spectator'),
                $realPlayers,
                null,
                'spectator',
            );
        }

        $position = $this->resolvePosition($realPlayers, $currentPlayer);

        if ($position === 'waiting_seat') {
            return $this->withPlayersContext(
                $this->withoutPrivateOpponentData($state, 'waiting_seat'),
                $realPlayers,
                $currentPlayer,
                'waiting_seat',
            );
        }

        $state = $position === 'opponent'
            ? $this->asOpponentPerspective($state, $currentPlayer)
            : $this->asPlayerPerspective($state, $currentPlayer);

        return $this->withPlayersContext($state, $realPlayers, $currentPlayer, $position);
    }


    /**
     * @param array<string, mixed> $state
     * @param Collection<int, PokerTablePlayer> $players
     * @return array<string, mixed>
     */
    private function multiSeatPerspective(array $state, Collection $players, ?User $user): array
    {
        $currentPlayer = $user
            ? $players->first(static fn (PokerTablePlayer $player): bool => (int) $player->user_id === (int) $user->id)
            : null;
        $isFinished = (bool) ($state['isFinished'] ?? false);
        $rawCurrentSeat = data_get($state, 'multiSeat.currentSeat', data_get($state, 'currentTurn.seatNumber'));
        $currentSeat = $isFinished || $rawCurrentSeat === null ? null : (int) $rawCurrentSeat;
        $multiSeatPlayers = collect(data_get($state, 'multiSeat.players', []))
            ->filter(static fn (mixed $player): bool => is_array($player))
            ->values();
        $currentSeatState = $currentPlayer
            ? $multiSeatPlayers->first(static fn (array $player): bool => (int) ($player['seatNumber'] ?? 0) === (int) $currentPlayer->seat_number)
            : null;
        $currentSeatActor = $currentSeat === null
            ? null
            : $multiSeatPlayers->first(static fn (array $player): bool => (int) ($player['seatNumber'] ?? 0) === $currentSeat);
        $isCurrentUserTurn = $currentPlayer !== null
            && $currentPlayer->seat_number !== null
            && $currentSeat !== null
            && (int) $currentPlayer->seat_number === $currentSeat
            && ! $isFinished;
        $currentBet = (int) ($state['currentBet'] ?? 0);
        $currentStreetBet = (int) ($currentSeatState['streetBet'] ?? 0);
        $amountToCall = max(0, $currentBet - $currentStreetBet);
        $playerStack = (int) ($currentSeatState['stack'] ?? 0);

        $state['playerCards'] = is_array($currentSeatState) ? (array) ($currentSeatState['cards'] ?? []) : [];
        $state['bestHand'] = is_array($currentSeatState) ? ($currentSeatState['bestHand'] ?? null) : null;
        unset($state['opponentCards'], $state['opponentBestHand']);

        if ($this->isMultiSeatShowdownResolved($state)) {
            $state = $this->withMultiSeatShowdownCards($state, $currentSeatState);
        }

        $state['playerStack'] = $playerStack;
        $state['playerStreetBet'] = $currentStreetBet;
        $state['opponentStack'] = (int) ($currentSeatActor['stack'] ?? 0);
        $state['opponentStreetBet'] = (int) ($currentSeatActor['streetBet'] ?? 0);
        $state['amountToCall'] = $amountToCall;
        $state['maximumRaiseTo'] = $playerStack + $currentStreetBet;
        $currentSeatIsAllIn = is_array($currentSeatState)
            && ((bool) ($currentSeatState['isAllIn'] ?? false) || $playerStack <= 0);
        $currentUserCanAct = $isCurrentUserTurn && ! $currentSeatIsAllIn && $playerStack > 0;

        $state['canCheck'] = $currentUserCanAct && $amountToCall === 0;
        $state['canCall'] = $currentUserCanAct && $amountToCall > 0;
        $state['canRaise'] = $currentUserCanAct && $playerStack > $amountToCall;
        $state['canAct'] = $currentUserCanAct;
        $currentSeatIsBot = is_array($currentSeatActor) && (bool) ($currentSeatActor['isBot'] ?? $currentSeatActor['is_bot'] ?? false);
        $state['botVsBotSimulation'] = false;
        $state['multiSeat']['currentSeatIsBot'] = $currentSeatIsBot;
        $state['multiSeat']['autoProcessCurrentBot'] = $currentSeatIsBot && ! $isFinished;
        $state = $this->normalizeMultiSeatTurnTimerForPerspective($state, $currentSeatIsBot, $isFinished);

        $state['multiplayerPerspective'] = [
            'role' => $currentPlayer ? 'multi_seat_player' : 'spectator',
            'tablePlayerId' => $currentPlayer?->id,
            'userId' => $currentPlayer?->user_id,
            'seatNumber' => $currentPlayer?->seat_number,
            'label' => 'Suas cartas',
        ];

        $state['playersContext'] = [
            'current' => $currentPlayer ? $this->serializePlayer($currentPlayer, true) : null,
            'opponents' => $players
                ->reject(static fn (PokerTablePlayer $player): bool => $currentPlayer && (int) $player->id === (int) $currentPlayer->id)
                ->values()
                ->map(fn (PokerTablePlayer $player): array => $this->serializePlayer($player, false))
                ->all(),
            'canonical' => [
                'player' => $currentPlayer ? $this->serializePlayer($currentPlayer, true) : null,
                'opponent' => is_array($currentSeatActor) ? [
                    'seatNumber' => (int) ($currentSeatActor['seatNumber'] ?? 0),
                    'nickname' => (string) ($currentSeatActor['nickname'] ?? 'Jogador'),
                    'displayName' => (string) ($currentSeatActor['displayName'] ?? $currentSeatActor['nickname'] ?? 'Jogador'),
                ] : null,
            ],
        ];

        $actorLabel = is_array($currentSeatActor)
            ? (string) ($currentSeatActor['nickname'] ?? $currentSeatActor['displayName'] ?? 'Jogador')
            : 'Jogador';

        $state['currentTurn'] = [
            ...(is_array($state['currentTurn'] ?? null) ? $state['currentTurn'] : []),
            'canonicalActor' => $isFinished ? null : 'seat:'.$currentSeat,
            'actor' => $isFinished ? null : ($isCurrentUserTurn ? 'player' : 'opponent'),
            'seatNumber' => $isFinished ? null : $currentSeat,
            'actorLabel' => $isFinished ? 'Mão finalizada' : ($isCurrentUserTurn ? ($currentSeatIsAllIn ? 'Você (all-in)' : 'Você') : $actorLabel),
            'isCurrentUserTurn' => $isCurrentUserTurn,
            'message' => $isFinished
                ? 'Mão multi-seat finalizada.'
                : ($isCurrentUserTurn
                    ? ($currentSeatIsAllIn
                        ? 'Você está all-in e sem fichas para agir. Aguardando os demais jogadores.'
                        : 'Sua vez de agir na mesa multi-seat.')
                    : 'Aguardando ação de '.$actorLabel.'.'),
        ];

        if (isset($state['turnTimer']) && is_array($state['turnTimer'])) {
            $state['turnTimer']['label'] = $state['currentTurn']['actorLabel'];
            $state['turnTimer']['isCurrentUserTurn'] = $isCurrentUserTurn && ! $currentSeatIsAllIn;
            $state['turnTimer']['currentSeatIsBot'] = $currentSeatIsBot;
            $state['turnTimer']['autoProcessCurrentBot'] = $currentSeatIsBot && ! $isFinished;
            $state['turnTimer']['currentSeatIsAllIn'] = $currentSeatIsAllIn;
        }

        if (isset($state['bettingSummary']) && is_array($state['bettingSummary'])) {
            $state['bettingSummary']['amountToCall'] = $amountToCall;
            $state['bettingSummary']['currentActor'] = $isFinished ? null : ($isCurrentUserTurn ? 'player' : 'opponent');
            $state['bettingSummary']['currentSeat'] = $currentSeat;
        }

        return $state;
    }

    /**
     * @param array<string, mixed> $state
     * @return array<string, mixed>
     */
    private function normalizeInterfaceFlags(array $state): array
    {
        $state['isWaitingForPlayers'] = (bool) ($state['isWaitingForPlayers'] ?? false);

        if (! $state['isWaitingForPlayers']) {
            unset($state['waitingForPlayers']);
        }

        return $state;
    }



    /**
     * Considera o showdown resolvido quando a mão terminou e o motor multi-seat
     * marcou explicitamente a fase de abertura. Isso evita depender apenas de
     * street=showdown, que pode não vir sincronizado em todos os caminhos de
     * reidratação/polling depois da resolução final.
     *
     * @param array<string, mixed> $state
     */
    private function isMultiSeatShowdownResolved(array $state): bool
    {
        if (! (bool) ($state['isFinished'] ?? false)) {
            return false;
        }

        return (string) ($state['street'] ?? '') === 'showdown'
            || (bool) data_get($state, 'multiSeat.showdownCardsRevealed', false)
            || (string) data_get($state, 'multiSeat.showdownResolutionPhase', '') === '10.12';
    }

    /**
     * No showdown real, todos os jogadores que chegaram vivos até a abertura
     * precisam ter suas cartas públicas na resposta da mesa. Antes disso,
     * continuamos escondendo cartas privadas dos adversários.
     *
     * @param array<string, mixed> $state
     * @param array<string, mixed>|null $currentSeatState
     * @return array<string, mixed>
     */
    private function withMultiSeatShowdownCards(array $state, ?array $currentSeatState): array
    {
        $players = collect(data_get($state, 'multiSeat.players', []))
            ->filter(static fn (mixed $player): bool => is_array($player))
            ->values();

        if ($players->isEmpty()) {
            return $state;
        }

        $cardsBySeat = [];

        $players = $players->map(function (array $player) use (&$cardsBySeat): array {
            $seatNumber = (int) ($player['seatNumber'] ?? 0);
            $hasFolded = (bool) ($player['hasFolded'] ?? false) || (string) ($player['status'] ?? '') === 'folded';
            $cards = $this->normalizeCards($player['cards'] ?? []);

            if ($seatNumber > 0 && ! $hasFolded && $cards !== []) {
                $cardsBySeat[$seatNumber] = $cards;
                $player['cards'] = $cards;
                $player['showdownCards'] = $cards;
            }

            if ($hasFolded) {
                unset($player['showdownCards']);
            }

            return $player;
        })->all();

        $state['multiSeat']['players'] = $players;
        $state['multiSeat']['showdownCardsRevealed'] = true;
        $state['multiSeat']['showdownCardsBySeat'] = $cardsBySeat;

        $currentSeatNumber = is_array($currentSeatState) ? (int) ($currentSeatState['seatNumber'] ?? 0) : 0;

        if ($currentSeatNumber > 0 && isset($cardsBySeat[$currentSeatNumber])) {
            $state['playerCards'] = $cardsBySeat[$currentSeatNumber];
        }

        $firstOpponentSeat = collect(array_keys($cardsBySeat))
            ->map(static fn (mixed $seat): int => (int) $seat)
            ->first(static fn (int $seat): bool => $seat > 0 && $seat !== $currentSeatNumber);

        if ($firstOpponentSeat !== null && isset($cardsBySeat[$firstOpponentSeat])) {
            $state['opponentCards'] = $cardsBySeat[$firstOpponentSeat];
        }

        return $state;
    }

    /**
     * @param mixed $cards
     * @return array<int, mixed>
     */
    private function normalizeCards(mixed $cards): array
    {
        if (! is_array($cards)) {
            return [];
        }

        return array_values(array_filter($cards));
    }

    /**
     * @return Collection<int, PokerTablePlayer>
     */
    private function realPlayers(PokerTable $table): Collection
    {
        return $table->realPlayers()
            ->orderByRaw('seat_number IS NULL')
            ->orderBy('seat_number')
            ->orderBy('joined_at')
            ->orderBy('id')
            ->get();
    }

    /**
     * @param Collection<int, PokerTablePlayer> $players
     */
    private function resolvePosition(Collection $players, PokerTablePlayer $currentPlayer): string
    {
        if ($currentPlayer->seat_number === null) {
            return 'waiting_seat';
        }

        if ((int) $currentPlayer->seat_number === 2) {
            return 'opponent';
        }

        if ((int) $currentPlayer->seat_number === 1) {
            return 'player';
        }

        $index = $players->values()->search(
            static fn (PokerTablePlayer $player): bool => (int) $player->id === (int) $currentPlayer->id,
        );

        return $index === 1 ? 'opponent' : 'player';
    }

    /**
     * @param array<string, mixed> $state
     * @return array<string, mixed>
     */
    private function asPlayerPerspective(array $state, PokerTablePlayer $currentPlayer): array
    {
        $state = $this->withoutPrivateOpponentData($state, 'player');

        $state['multiplayerPerspective'] = [
            'role' => 'player',
            'tablePlayerId' => $currentPlayer->id,
            'userId' => $currentPlayer->user_id,
            'seatNumber' => $currentPlayer->seat_number,
            'label' => 'Suas cartas',
        ];

        return $state;
    }

    /**
     * @param array<string, mixed> $state
     * @return array<string, mixed>
     */
    private function asOpponentPerspective(array $state, PokerTablePlayer $currentPlayer): array
    {
        $originalPlayerCards = $state['playerCards'] ?? [];
        $originalOpponentCards = $state['opponentCards'] ?? [];
        $originalBestHand = $state['bestHand'] ?? null;
        $originalOpponentBestHand = $state['opponentBestHand'] ?? null;
        $originalPlayerStack = (int) ($state['playerStack'] ?? 1000);
        $originalOpponentStack = (int) ($state['opponentStack'] ?? 1000);
        $originalPlayerStreetBet = (int) ($state['playerStreetBet'] ?? 0);
        $originalOpponentStreetBet = (int) ($state['opponentStreetBet'] ?? 0);

        $state['playerCards'] = $originalOpponentCards;
        $state['bestHand'] = $originalOpponentBestHand;
        $state['playerStack'] = $originalOpponentStack;
        $state['opponentStack'] = $originalPlayerStack;
        $state['playerStreetBet'] = $originalOpponentStreetBet;
        $state['opponentStreetBet'] = $originalPlayerStreetBet;

        if (isset($state['bettingSummary']) && is_array($state['bettingSummary'])) {
            $state['bettingSummary']['playerCommitted'] = $originalOpponentStreetBet;
            $state['bettingSummary']['opponentCommitted'] = $originalPlayerStreetBet;
        }

        if ((bool) ($state['isFinished'] ?? false)) {
            $state['opponentCards'] = $originalPlayerCards;
            $state['opponentBestHand'] = $originalBestHand;
        } else {
            unset($state['opponentCards'], $state['opponentBestHand']);
        }

        $state['multiplayerPerspective'] = [
            'role' => 'opponent',
            'tablePlayerId' => $currentPlayer->id,
            'userId' => $currentPlayer->user_id,
            'seatNumber' => $currentPlayer->seat_number,
            'label' => 'Suas cartas',
        ];

        return $state;
    }

    /**
     * @param array<string, mixed> $state
     * @return array<string, mixed>
     */
    private function withoutPrivateOpponentData(array $state, string $role): array
    {
        $isFinished = (bool) ($state['isFinished'] ?? false);
        $isBotVsBotSimulation = (bool) ($state['botVsBotSimulation'] ?? false);

        if (! $isFinished && ! $isBotVsBotSimulation) {
            unset($state['opponentCards'], $state['opponentBestHand']);
        }

        $state['multiplayerPerspective'] = [
            'role' => $role,
        ];

        return $state;
    }

    /**
     * @param array<string, mixed> $state
     * @param Collection<int, PokerTablePlayer> $players
     * @return array<string, mixed>
     */
    private function withPlayersContext(array $state, Collection $players, ?PokerTablePlayer $currentPlayer, string $role): array
    {
        $playerOne = $players->first(static fn (PokerTablePlayer $player): bool => (int) $player->seat_number === 1)
            ?? $players->values()->get(0);
        $playerTwo = $players->first(static fn (PokerTablePlayer $player): bool => (int) $player->seat_number === 2)
            ?? $players->values()->get(1);

        $currentCanonicalActor = $role === 'opponent' ? 'opponent' : ($role === 'player' ? 'player' : null);

        $state['playersContext'] = [
            'current' => $currentPlayer ? $this->serializePlayer($currentPlayer, true) : null,
            'opponents' => $players
                ->reject(static fn (PokerTablePlayer $player): bool => $currentPlayer && (int) $player->id === (int) $currentPlayer->id)
                ->values()
                ->map(fn (PokerTablePlayer $player): array => $this->serializePlayer($player, false))
                ->all(),
            'canonical' => [
                'player' => $playerOne ? $this->serializePlayer($playerOne, $currentCanonicalActor === 'player') : null,
                'opponent' => $playerTwo ? $this->serializePlayer($playerTwo, $currentCanonicalActor === 'opponent') : null,
            ],
        ];

        $state['actionHistory'] = $this->personalizeHistory($state['actionHistory'] ?? [], $role, $state['playersContext']['canonical']);
        $state['conclusion'] = $this->personalizeConclusion($state['conclusion'] ?? null, $role, $state['playersContext']['canonical']);
        $state['lastAction'] = $this->personalizeLastAction($state['lastAction'] ?? null, $role, $state['playersContext']['canonical']);

        return $this->withTurnContext($state, $role, $state['playersContext']['canonical']);
    }

    /**
     * @param array<string, mixed> $state
     * @param array<string, mixed> $canonicalPlayers
     * @return array<string, mixed>
     */
    private function withTurnContext(array $state, string $role, array $canonicalPlayers): array
    {
        if ((bool) ($state['isWaitingForPlayers'] ?? false)) {
            $message = $role === 'waiting_seat'
                ? 'Escolha um assento livre para participar da mão.'
                : (string) data_get($state, 'waitingForPlayers.message', 'Aguardando jogadores suficientes para iniciar.');

            $state['currentTurn'] = [
                ...(is_array($state['currentTurn'] ?? null) ? $state['currentTurn'] : []),
                'canonicalActor' => 'waiting',
                'actor' => 'waiting',
                'actorLabel' => 'Aguardando jogadores',
                'isCurrentUserTurn' => false,
                'message' => $message,
            ];

            $state['amountToCall'] = 0;
            $state['minimumRaiseTo'] = 0;
            $state['maximumRaiseTo'] = 0;
            $state['canCheck'] = false;
            $state['canCall'] = false;
            $state['canRaise'] = false;
            $state['canAct'] = false;
            $state['turnTimer'] = null;

            if (isset($state['bettingSummary']) && is_array($state['bettingSummary'])) {
                $state['bettingSummary']['amountToCall'] = 0;
                $state['bettingSummary']['currentActor'] = 'waiting';
            }

            return $state;
        }

        $canonicalActor = (string) data_get($state, 'currentTurn.actor', 'player');
        $canonicalActor = $canonicalActor === 'opponent' ? 'opponent' : 'player';
        $visibleActor = $this->visibleActor($canonicalActor, $role);
        $isCurrentUserTurn = in_array($role, ['player', 'opponent'], true) && $visibleActor === 'player';
        $amountToCall = $this->amountToCallForVisiblePlayer($state);
        $maximumRaiseTo = ((int) ($state['playerStreetBet'] ?? 0)) + ((int) ($state['playerStack'] ?? 0));

        $state['currentTurn'] = [
            ...(is_array($state['currentTurn'] ?? null) ? $state['currentTurn'] : []),
            'canonicalActor' => $canonicalActor,
            'actor' => $visibleActor,
            'actorLabel' => $this->actorLabel($canonicalActor, $role, $canonicalPlayers),
            'isCurrentUserTurn' => $isCurrentUserTurn,
            'message' => $isCurrentUserTurn
                ? 'Sua vez de agir.'
                : ($role === 'waiting_seat'
                    ? 'Escolha um assento livre para participar da mão.'
                    : 'Aguardando ação de '.$this->actorLabel($canonicalActor, $role, $canonicalPlayers).'.'),
        ];

        $state['amountToCall'] = $amountToCall;
        $state['minimumRaiseTo'] = ((int) ($state['currentBet'] ?? 0)) + ((int) ($state['minimumRaise'] ?? 10));
        $state['maximumRaiseTo'] = $maximumRaiseTo;
        $state['canCheck'] = $isCurrentUserTurn && $amountToCall === 0 && ! (bool) ($state['isFinished'] ?? false);
        $state['canCall'] = $isCurrentUserTurn && $amountToCall > 0 && ((int) ($state['playerStack'] ?? 0)) > 0;
        $state['canRaise'] = $isCurrentUserTurn && ((int) ($state['playerStack'] ?? 0)) > $amountToCall && ! (bool) ($state['isFinished'] ?? false);
        $state['canAct'] = $isCurrentUserTurn && ! (bool) ($state['isFinished'] ?? false);

        if (isset($state['turnTimer']) && is_array($state['turnTimer'])) {
            $state['turnTimer']['label'] = $state['currentTurn']['actorLabel'];
            $state['turnTimer']['isCurrentUserTurn'] = $isCurrentUserTurn;
        }

        if (isset($state['bettingSummary']) && is_array($state['bettingSummary'])) {
            $state['bettingSummary']['amountToCall'] = $amountToCall;
            $state['bettingSummary']['currentActor'] = $visibleActor;
        }

        return $state;
    }

    /**
     * @param array<string, mixed> $state
     */
    private function amountToCallForVisiblePlayer(array $state): int
    {
        return max(0, (int) ($state['currentBet'] ?? 0) - (int) ($state['playerStreetBet'] ?? 0));
    }

    /**
     * Mantém o contrato privado coerente com a regra visual da FASE 10.18.3:
     * humano tem 30s e bot multi-seat tem 10s. O estado persistido normalmente
     * já vem correto pelo PokerTurnTimerService, mas esta normalização protege
     * respostas que ainda carreguem um timer antigo durante reidratação/polling.
     *
     * @param array<string, mixed> $state
     * @return array<string, mixed>
     */
    private function normalizeMultiSeatTurnTimerForPerspective(array $state, bool $currentSeatIsBot, bool $isFinished): array
    {
        if ($isFinished || ! isset($state['turnTimer']) || ! is_array($state['turnTimer'])) {
            return $state;
        }

        $secondsTotal = $currentSeatIsBot ? 10 : 30;
        $currentSecondsTotal = (int) ($state['turnTimer']['secondsTotal'] ?? $secondsTotal);
        $state['turnTimer']['secondsTotal'] = $secondsTotal;
        $state['turnTimer']['label'] = $currentSeatIsBot
            ? 'Tempo da jogada do bot'
            : 'Tempo da jogada';

        if ($currentSecondsTotal !== $secondsTotal && isset($state['turnTimer']['startedAt'])) {
            $startedAt = \Illuminate\Support\Carbon::parse((string) $state['turnTimer']['startedAt'])
                ->timezone(config('app.timezone'));
            $expiresAt = $startedAt->copy()->addSeconds($secondsTotal);
            $now = now()->timezone(config('app.timezone'));
            $secondsRemaining = max(0, $now->diffInSeconds($expiresAt, false));

            $state['turnTimer']['expiresAt'] = $expiresAt->toIso8601String();
            $state['turnTimer']['serverNow'] = $now->toIso8601String();
            $state['turnTimer']['secondsRemaining'] = $secondsRemaining;
            $state['turnTimer']['isExpired'] = $secondsRemaining <= 0;
        }

        return $state;
    }

    private function serializePlayer(PokerTablePlayer $player, bool $isCurrent): array
    {
        return [
            'id' => $player->id,
            'userId' => $player->user_id,
            'nickname' => $player->nickname,
            'displayName' => $isCurrent ? 'Você' : ($player->nickname ?: 'Jogador'),
            'stack' => $player->stack,
            'status' => $player->status,
            'seatNumber' => $player->seat_number,
            'isCurrent' => $isCurrent,
        ];
    }

    /**
     * @param mixed $history
     * @param array<string, mixed> $canonicalPlayers
     * @return array<int, array<string, mixed>>
     */
    private function personalizeHistory(mixed $history, string $role, array $canonicalPlayers): array
    {
        if (! is_array($history)) {
            return [];
        }

        return array_values(array_map(
            function (mixed $item) use ($role, $canonicalPlayers): array {
                $item = is_array($item) ? $item : [];
                $canonicalActor = (string) ($item['actor'] ?? 'player');
                $visibleActor = $this->visibleActor($canonicalActor, $role);
                $actorLabel = $this->actorLabel($canonicalActor, $role, $canonicalPlayers);

                $item['canonicalActor'] = $canonicalActor;
                $item['actor'] = $visibleActor;
                $item['actorLabel'] = $actorLabel;
                $item['message'] = $this->personalizeText((string) ($item['message'] ?? ''), $role, $canonicalPlayers);

                return $item;
            },
            array_filter($history, static fn (mixed $item): bool => is_array($item)),
        ));
    }

    /**
     * @param mixed $conclusion
     * @param array<string, mixed> $canonicalPlayers
     * @return array<string, mixed>|null
     */
    private function personalizeConclusion(mixed $conclusion, string $role, array $canonicalPlayers): ?array
    {
        if (! is_array($conclusion)) {
            return null;
        }

        $winner = $conclusion['winner'] ?? null;

        if (is_array($winner)) {
            $canonicalWinner = (string) ($winner['player'] ?? '');

            if ($canonicalWinner !== 'tie') {
                $winner['canonicalPlayer'] = $canonicalWinner;
                $winner['player'] = $this->visibleActor($canonicalWinner, $role);
                $winner['label'] = $this->actorLabel($canonicalWinner, $role, $canonicalPlayers);
            }

            $conclusion['winner'] = $winner;
        }

        $conclusion['message'] = $this->personalizeText((string) ($conclusion['message'] ?? ''), $role, $canonicalPlayers);

        return $conclusion;
    }

    /**
     * @param mixed $lastAction
     * @param array<string, mixed> $canonicalPlayers
     * @return array<string, mixed>|null
     */
    private function personalizeLastAction(mixed $lastAction, string $role, array $canonicalPlayers): ?array
    {
        if (! is_array($lastAction)) {
            return null;
        }

        $lastAction['message'] = $this->personalizeText((string) ($lastAction['message'] ?? ''), $role, $canonicalPlayers);

        return $lastAction;
    }

    private function visibleActor(string $canonicalActor, string $role): string
    {
        if ($canonicalActor === 'tie') {
            return 'tie';
        }

        if ($role === 'opponent') {
            return $canonicalActor === 'opponent' ? 'player' : 'opponent';
        }

        return $canonicalActor === 'opponent' ? 'opponent' : 'player';
    }

    /**
     * @param array<string, mixed> $canonicalPlayers
     */
    private function actorLabel(string $canonicalActor, string $role, array $canonicalPlayers): string
    {
        if ($canonicalActor === 'tie') {
            return 'Empate';
        }

        $canonicalPlayer = $canonicalPlayers[$canonicalActor] ?? null;

        if ($role !== 'spectator' && $this->visibleActor($canonicalActor, $role) === 'player') {
            return 'Você';
        }

        return is_array($canonicalPlayer)
            ? (string) ($canonicalPlayer['nickname'] ?? $canonicalPlayer['displayName'] ?? 'Jogador')
            : ($canonicalActor === 'opponent' ? 'Oponente' : 'Jogador');
    }

    /**
     * @param array<string, mixed> $canonicalPlayers
     */
    private function personalizeText(string $text, string $role, array $canonicalPlayers): string
    {
        if ($text === '') {
            return $text;
        }

        $playerLabel = $this->actorLabel('player', $role, $canonicalPlayers);
        $opponentLabel = $this->actorLabel('opponent', $role, $canonicalPlayers);

        return str_replace(
            ['Você', 'você', 'O oponente', 'o oponente', 'Oponente'],
            [$playerLabel, mb_strtolower($playerLabel), $opponentLabel, mb_strtolower($opponentLabel), $opponentLabel],
            $text,
        );
    }
}
